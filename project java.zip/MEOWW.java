/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.meoww;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author pro
 */
public class MEOWW {

    public static void main(String[] args) {
          int selection, userChoice;
        String enterKey = ""; // to handel the enter key after scan Int
        String bookDay="";
        String [] day = {"Sun","Mon","Tue","Wed","Thu"};
        String [] dayStatus = {"Free","Free","Booked","Free","Free"};

        Scanner scan = new Scanner(System.in);

        Cat cat1 = new Cat("Kol","Seal point",1,"m","Birman",2,"3212321","Missing");
        Cat cat2 = new Cat("Lasy","Blue point",2,"f","BomBay",2,"5646987","4Adopt");
        Cat cat3 = new Cat("Tara","Chocolate",2,"m","Shorthair",2,"5947814","4Sale");
        Cat cat4 = new Cat("Momo","Lilac point",1,"f","Burmese",2,"987654","4Adopt");
        Cat cat5 = new Cat("Regdoll","Silver",3,"m","Regdoll",2,"6987456","Missing");
        Cat cat6 = new Cat("Him","Black",1,"f","Himalayan",2,"9517531","4Sale");
        Cat cat7 = new Cat("Bom","Cream",2,"m","Munchkin",2,"3698745","4Adopt");
        Cat cat8 = new Cat("Mola","Red",3,"f","British",2,"4562587","Missing");
        Cat cat9 = new Cat("Cato","Blue",2,"m","Bombay",2,"3578954","4Sale");

        ArrayList<Cat> cats = new ArrayList<Cat>();
        cats.add(cat1);     cats.add(cat2);     cats.add(cat3);
        cats.add(cat4);     cats.add(cat5);     cats.add(cat6);
        cats.add(cat7);     cats.add(cat8);     cats.add(cat9);

        Admin admin1 = new Admin("Sadeem","admin", "admin");
        Admin admin2 = new Admin();

        Customer customer = new Customer("Dana","55 555 5555");

        Bill bill = new Bill("",0);
        ArrayList<Bill> Bills = new ArrayList<Bill>();

        do {
            System.out.println();
            System.out.println("   Welcome to MEOW MEOW Salon");
            System.out.println("  ----------------------------");
            System.out.println("    Select #:");
            System.out.println("\t\t1- Admin");
            System.out.println("\t\t2- Customer");
            System.out.println("\t\t3- Total Bill");
            System.out.println("\t\t4- End\n");
            System.out.print("\tPlease Enter your choice: ");
            selection = scan.nextInt();
            enterKey = scan.nextLine();
            switch(selection){
                case 1:
                    // Administrator menu.
                    String loginName = "", loginPass = "";
                    System.out.println("\t\t Hello Mr. Admin");
                    System.out.println("\t\t ^^^^^^^^^^^^^^^^^^");
                    System.out.println("\tPlease Enter your name and password");
                    System.out.println("\t^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^");
                    System.out.print("\tAdmin Name: ");
                    loginName = scan.nextLine();
                    System.out.print("\tAdmin Pass: ");
                    loginPass = scan.nextLine();
                    if (loginName.equals(admin1.getAdminName()) &&
                            loginPass.equals(admin1.getAdminPass()) ){
                        System.out.println("\tWelcome to Admin Services");
                        do {
                            System.out.println("\t1- Display all cats.");
                            System.out.println("\t2- Change Appointment");
                            System.out.println("\t3- Delete cat from list");
                            System.out.println("\t4- Exit");
                            System.out.print("\tEnter your Admin service choice: ");
                            userChoice = scan.nextInt();
                            enterKey = scan.nextLine();
                            switch (userChoice) {
                                case 1: // A list of Cats
                                    System.out.println("\t\t A list of Cats");
                                    System.out.println("\t\t----------------");
                                    admin1.display(cats);
                                    break;
                                case 2:
                                    System.out.println("\t\t Change Appointment");
                                    System.out.println("\t\t-------------------");
                                    admin1.changeAvailableApp(day, dayStatus);

                                    System.out.println("\t\tHere is a list of days and their status");
                                    System.out.println("\t\t\t\tAfter change");
                                    for (int i=0; i<day.length; i++){
                                        System.out.println("\t\t\t"+day[i]+" => "+dayStatus[i]);
                                    }
                                    System.out.println("\t\t-------------------");
                                    break;
                                case 3:
                                    System.out.println("\t\t Warning Delete Cat from the List");
                                    admin1.deleteCat(cats);
                                    System.out.println("\n\t\tHere is a list of Cat we have left");
                                    System.out.println("\t\t\t\tAfter Delete");
                                    admin1.display(cats);
                                    break;
                                case 4:
                                    System.out.println("\t\t Thank you Mr. Admin");
                                    System.out.println("\t\t   Have a nice day");
                                    System.out.println("\t\t----------------------");
                                    break;
                                default:
                                    System.out.println("\t\t Choices are 1 through 4 Only");
                                    System.out.println("\t\t------------------------------");
                                    break;
                            } // switch end
                        }while (userChoice != 4);
                        // admin name and pass are OK
                    } else{
                        System.out.println("\t\tAdministrator name or password are NOT Correct");
                        System.out.println("\t\t^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^");
                    }// end else - admin name or pass are bad.
                    break; // case 1 admin menu
                case 2:
                    // customer menu.
                    do {
                        System.out.println("");
                        System.out.println("\tWelcome to MEOW MEOW Salon");
                        System.out.println("\t\tCustomer Menu");
                        System.out.println("\t^^^^^^^^^^^^^^^^^^^^^^^^^^");
                        System.out.println("\t1- Report Missing Cats");
                        System.out.println("\t2- Search for adoption");
                        System.out.println("\t3- Offer adoption");
                        System.out.println("\t4- Clinic Services");
                        System.out.println("\t5- Cat Setting Services");
                        System.out.println("\t6- Salon Services");
                        System.out.println("\t7- Exit");
                        System.out.print("\tEnter your service of choice: ");
                        userChoice = scan.nextInt();
                        enterKey = scan.nextLine();
                        switch (userChoice) {
                            case 1: // Report Missing Cats
                                System.out.println("\t\tReport Missing Cats");
                                System.out.println("\t\t-------------------");
                                customer.report_missing_cat(cats);
                                System.out.printf("\t%.10s %10.10s %8.5s %3.10s %8s %10.10s %10.10s %n","Cat Name",
                                        "Color","Age","Gender","Breed","Weight","Contact");
                                // display a list of Missing cats
                                System.out.println("\t\tHere is a list of Missing Cats");
                                System.out.println("\t\t------------------------------");
                                for (Cat meow : cats){
                                    if(meow.status.equals("Missing")){
                                        System.out.printf("\t  %-10.10s %-12.8s %d %5s %12.12s %5d %12s%n",
                                                meow.getCatName(), meow.getColor(), meow.getAge(),
                                                meow.getGender(), meow.getBreed(),meow.getWeight(),meow.getContact());
                                    }// end if Missing
                                }// end for display cats - Missing
                                break;
                            case 2:
                                System.out.println("\t\tSearch for adoption");
                                System.out.println("\t\t-------------------");
                                customer.search_for_adoption(cats);
                                break;
                            case 3:
                                System.out.println("\t\tOffer adoption");
                                System.out.println("\t\t--------------");
                                customer.offer_adoption(cats);
                                break;
                            case 4:
                                System.out.println("\t\tClinic Services");
                                System.out.println("\t\t---------------");
                                do {
                                    System.out.println("");
                                    System.out.println("\t1- Sterilization appointment");
                                    System.out.println("\t2- Immunization appointment");
                                    System.out.println("\t3- Checkup appointment");
                                    System.out.println("\t4- Exit");
                                    System.out.print("\tPlease Enter a num: ");
                                    userChoice = scan.nextInt();
                                    enterKey = scan.nextLine();
                                    switch(userChoice) {
                                        case 1:
                                            System.out.println("");
                                            System.out.println("\tSterilization appointment");
                                            System.out.println("\t-------------------------");
                                            System.out.println("\tAvailable Days are:");
                                            System.out.println("\tDay  \tStatus");
                                            System.out.println("\t---  \t------");
                                            for(int i=0; i<5; i++){
                                                if(dayStatus[i] == "Free"){
                                                    System.out.print("\t"+day[i]+"\t\t"+dayStatus[i]);
                                                    System.out.println("");
                                                }else{
                                                    System.out.print("All appointments are busy this week ");
                                                }
                                            }
                                            System.out.println("");
                                            System.out.print("Please Enter the Day of your choice: ");
                                            bookDay = scan.nextLine();
                                            for(int i=0; i<5; i++){
                                                // if service is booked, add it to bills
                                                if(day[i].equals(bookDay) && dayStatus[i].equals("Free")){
                                                    dayStatus[i] = "Booked";
                                                    customer.addToBills(Bills,"Sterilization",150);
                                                }
                                            }
                                            break;// Sterilization appointment
                                        case 2:
                                            System.out.println("");
                                            System.out.println("\tImmunization appointment");
                                            System.out.println("\t------------------------");
                                            System.out.println("\tAvailable Days are:");
                                            System.out.println("\tDay  \tStatus");
                                            System.out.println("\t---  \t------");
                                            for(int i=0; i<5; i++){
                                                if(dayStatus[i] == "Free"){
                                                    System.out.print("\t"+day[i]+"\t\t"+dayStatus[i]);
                                                    System.out.println("");
                                                }else{
                                                    System.out.print("All appointments are busy this week ");
                                                }
                                            }
                                            System.out.println("");
                                            System.out.print("Please Enter the Day of your choice: ");
                                            bookDay = scan.nextLine();
                                            for(int i=0; i<5; i++){
                                                // if service booked, add to bill
                                                if(day[i].equals(bookDay) && dayStatus[i].equals("Free")){
                                                    dayStatus[i] = "Booked";
                                                    customer.addToBills(Bills,"Immunization",200);
                                                }
                                            }
                                            break;// Immunization appointment
                                        case 3:
                                            System.out.println("");
                                            System.out.println("\tCheckup appointment");
                                            System.out.println("\t-------------------");
                                            System.out.println("\tAvailable Days are:");
                                            System.out.println("\tDay  \tStatus");
                                            System.out.println("\t---  \t------");
                                            for(int i=0; i<5; i++){
                                                if(dayStatus[i] == "Free"){
                                                    System.out.print("\t"+day[i]+"\t\t" + dayStatus[i]);
                                                    System.out.println("");
                                                }else{
                                                    System.out.print("All appointments are busy this week ");
                                                }
                                            }
                                            System.out.println("");
                                            System.out.print("Please Enter the Day of your choice: ");
                                            bookDay = scan.nextLine();
                                            for(int i=0; i<5; i++){
                                                // if service booked, add to bill
                                                if(day[i].equals(bookDay) && dayStatus[i].equals("Free")){
                                                    dayStatus[i] = "Booked";
                                                    customer.addToBills(Bills,"Checkup",130);
                                                }
                                            }
                                            break;//Checkup appointment
                                        case 4:
                                            System.out.println("");
                                            System.out.println("\t-------- DONE --------");
                                            break;
                                        default:
                                            System.out.println("\tChoices are 1 through 4 Only.");
                                            break;
                                    }// end of switch on clinic services
                                }while(userChoice != 4);
                                break;//Clinic Services
                            case 5:
                                System.out.println("\t\tCat Setting Services");
                                System.out.println("\t\t--------------------");
                                customer.cat_setting(cats);
                                customer.addToBills(Bills,"Setting",150);
                                break;
                            case 6:
                                System.out.println("\t\tSalon Services");
                                System.out.println("\t\t--------------");
                                do {
                                    System.out.println("");
                                    System.out.println("\t1- Shower");
                                    System.out.println("\t2- Haircut and Nails");
                                    System.out.println("\t3- Both 1 & 2");
                                    System.out.println("\t4- Exit");
                                    System.out.print("\tPlease Enter a num: ");
                                    userChoice = scan.nextInt();
                                    switch(userChoice) {
                                        case 1:
                                            System.out.println("");
                                            System.out.println("\tِAdd Shower Service");
                                            System.out.println("\t----- 50 SR ------");
                                            customer.addToBills(Bills,"Shower",50);
                                            break;
                                        case 2:
                                            System.out.println("");
                                            System.out.println("\tAdd Haircut and Nails");
                                            System.out.println("\t----- 50 SR ------");
                                            customer.addToBills(Bills,"Haircut",50);
                                            break;
                                        case 3:
                                            System.out.println("");
                                            System.out.println("\tAdd Both 1 & 2");
                                            System.out.println("\t--- 100 SR ---");
                                            customer.addToBills(Bills,"Both",100);
                                            break;
                                        case 4:
                                            System.out.println("");
                                            System.out.println("\t--- DONE ---");
                                            break;
                                        default:
                                            System.out.println("\tChoices are 1 through 4 Only.");
                                            break;
                                    }// end of switch on salon services
                                }while(userChoice != 4);

                                break;
                            case 7:
                                System.out.println("\t\tExit Customer Menu");
                                System.out.println("\t\t\tMEOW MEOW");
                                System.out.println("\t\t------------------");
                                break;
                            default:
                                System.out.println("\t\tChoices are 1 through 7 Only");
                                System.out.println("\t\t----------------------------");
                                break;
                        } // switch end
                    }while (userChoice != 7);
                    break;// case1 user menu
                case 3:
                    System.out.println("\t\tMEOW Bill Service");
                    customer.calculate_bill(Bills);
                    break; // Bill service
                case 4:
                    System.out.println("\t\tMEOW CAT SALON");
                    System.out.println("\t\t   MEOW MEOW");
                    System.out.println("\t\t   =Bye bye");
                    break; // exit program
                default:
                    System.out.println();
                    System.out.println("\t\t\t* * * Available choices are 1, 2, 3, 4 Only");
                    System.out.println("\t\t\t* * * You may try again:");
                    break;
            }// switch for Admin or Customer
        }while(selection != 4); // end of main program
    }
}
