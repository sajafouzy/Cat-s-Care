/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.meoww;
import java.util.ArrayList;
import java.util.Scanner;
/**
 *
 * @author pro
 */

public class Admin extends User{
    private static final String name = "";
    String adminName;
    String adminPass;

    public Admin(String name, String adminName, String adminPass) {
        super(name);
        this.adminName = adminName;
        this.adminPass = adminPass;
    }
    // overloaded constructor
    public Admin(){
        super(name);
    }

    @Override
    public String toString() {
        return "Admin{}";
    }

    public String getAdminName(){
        return this.adminName;
    }
    public String getAdminPass(){
        return this.adminPass;
    }

    // View cats list
    public void display(ArrayList catList){
        System.out.printf("\t# %-10s %-12s %3s %5s \t\t%-12s \t%-10s%n",
                "Cat Name","Color","Age","Gender","Breed", "Status");
        System.out.printf("\t  %-10s %-12s %3s %5s \t\t%-12s \t%-10s%n",
                "--------","-----","---","------","-----", "------");
        // display a list of Missing cats
        for (int i=0; i<catList.size(); i++){
            Cat meow = (Cat) catList.get(i);
                System.out.printf("\t%s %-10s %-12s %3d %5s \t\t%-12s \t%-10s%n",
                        (i+1),meow.getCatName(), meow.getColor(), meow.getAge(),
                        meow.getGender(), meow.getBreed(), meow.getStatus());
        }// end for display all cats
        System.out.println("  -----------------------------------------------------------------");
    }// end display all cats ()

    // change appointment Free or busy.
    // declare a method that returns an array of String
    public String[] changeAvailableApp(String [] day, String [] status){
        Scanner scan = new Scanner(System.in);
        String dayName;
        String newStatus;
        for (int i=0; i<day.length; i++){
            System.out.println("\t\t"+day[i]+" is "+status[i]);
        }
        System.out.println("\tChange what Day to new Status (Free / Booked)");
        System.out.print("\tEnter day Name:\t\t");
        dayName= scan.nextLine();
        System.out.print("\tEnter new Status:\t");
        newStatus= scan.nextLine();
        for (int i=0; i<day.length; i++){
            if (day[i].equals(dayName)){
                status[i]=newStatus;
            }
        }
        System.out.println("\t\t-------------------");
        return status; // return the string array after changing it
    }// end add missing act ()

    // delete a cat from the list
    public void deleteCat(ArrayList catList){
            Scanner scan = new Scanner(System.in);
            System.out.print("\t\t Enter Cat name to delete:\t");
            String delCat;
            delCat=scan.nextLine();
            int found=0;
            for (int i=0; i< catList.size(); i++){
                Cat cat = (Cat) catList.get(i);
                // compare object with variable
                if(cat.getCatName().equals(delCat)){
                    // Delete the whole object
                    catList.remove(catList.get(i));
                    System.out.println("\t\t"+delCat+" Deleted.");
                    found=1;
                    // Break the loop it is not Necessary to continue looping
                    // after the ITEM has been removed
                    i= catList.size();
                }
            } // end of for loop
            // ERROR handling, if the search string does not exist.
            if( found == 0){
                System.out.println("\t\t\t\tWe cant find MEOW\""+delCat+"\" among the MEOWS");
            }
    }// end delete a cat ()
} // end of class Admin

