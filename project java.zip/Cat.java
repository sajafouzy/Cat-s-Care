/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.meoww;

/**
 *
 * @author pro
 */
public class Cat {
    String catName;
    String color;
    int age;
    String gender;
    String breed; // type
    int weight;
    String contact;
    String status;
    public Cat(String catName, String color, int age, String gender, String breed, int weight, String contact, String status) {
        this.catName = catName;
        this.color = color;
        this.age = age;
        this.gender = gender;
        this.breed = breed;
        this.weight = weight;
        this.contact = contact;
        this.status = status;
    }

    @Override
    public String toString() {
        return "\n\tCat{" +
                "\n\t, CatName= '" + catName + '\'' +
                "\n\t, Color= '" + color + '\'' +
                "\n\t, Age= " + age +
                "\n\t, Gender =" + gender +
                "\n\t, Breed= '" + breed + '\'' +
                "\n\t, Weight= " + weight +
                "\n\t, Contact= '" + contact + '\'' +
                "\n\t, Status= '" + status + '\'' +
                '}'+"\n";
    }

    public String getCatName() {
        return catName;
    }

    public void setCatName(String catName) {
        this.catName = catName;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getBreed() {
        return breed;
    }

    public void setBreed(String breed) {
        this.breed = breed;
    }

    public int getWeight() {
        return weight;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
    
}
