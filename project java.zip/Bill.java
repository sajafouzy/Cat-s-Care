/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.meoww;

/**
 *
 * @author pro
 */
public class Bill {
    String service;
    int price;
    int tax=10;

    public Bill(String service, int price) {
        this.service = service;
        this.price = price;
    }

    @Override
    public String toString() {
        return "Bill{" +
                "service='" + service + '\'' +
                ", price=" + price +
                ", tax=" + tax +
                '}';
    }

    public String getService() {
        return service;
    }

    public void setService(String service) {
        this.service = service;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public int getTax() {
        return tax;
    }

} // end of Bill class

