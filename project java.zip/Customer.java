/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.meoww;
import java.util.ArrayList;
import java.util.Scanner;
/**
 *
 * @author pro
 */
public class Customer extends User{
    private static final String name ="" ;
    Scanner scan = new Scanner(System.in);
    String enterKey;
    public Customer(String name, String tel) {
        super(name);
    }

    // overload constructor
    public Customer() {
        super(name);
    }


    @Override
    public String toString() {
        return "Customer{}";
    }

    public void report_missing_cat(ArrayList listOfCats){
        // new Temporary cat object.
        // since this is reporting missing cats,
        // the status "Missing" was added in the initialisation.
        Cat missingCat =
                new Cat("","",0,"",
                        "",0,"","Missing");

        System.out.println("***** This might help you find your cat *****");
        System.out.print("\t\t Enter the cat Name: ");
        missingCat.setCatName(scan.nextLine());
        System.out.print("\t\t Enter cat color: ");
        missingCat.setColor(scan.nextLine());
        System.out.print("\t\t Enter age: ");
        missingCat.setAge(scan.nextInt());
        enterKey = scan.nextLine();
        System.out.print("\t\t Enter gender m/f: ");
        missingCat.setGender(scan.nextLine());
        System.out.print("\t\t Enter cat breed: ");
        missingCat.setBreed(scan.nextLine());
        System.out.print("\t\t Enter cat weight: ");
        missingCat.setWeight(scan.nextInt());
        enterKey = scan.nextLine();
        System.out.print("\t\t Enter Contact #: ");
        missingCat.setContact(scan.nextLine());
        listOfCats.add(missingCat);
    } // end of report missing cat method
    public void search_for_adoption(ArrayList listOfCats){
        System.out.printf("\t%.10s %10.10s %8.5s %3.10s %8s%n",
                "Cat Name","Color","Age","Gender","Breed");
        // display a list of Missing cats
        for (int i=0; i<listOfCats.size(); i++){
            Cat meow = (Cat) listOfCats.get(i);
            if(meow.status.equals("4Adopt")){
                System.out.printf("\t  %-10.10s %-12.8s %d %5.12s %12s%n",
                        meow.getCatName(), meow.getColor(), meow.getAge(),
                        meow.getGender(), meow.getBreed());
            }// end if Missing
        }// end for display cats - Missing
        System.out.print("\tPlease enter the cat name ");
        String toAdapt = scan.nextLine();
        for (int i=0; i<listOfCats.size(); i++){
            Cat meow = (Cat) listOfCats.get(i);
            if(meow.catName.equals(toAdapt)){
                System.out.println("\tHere is the Contact #: "+ meow.getContact()+
                        " for => "+meow.getCatName());
            }// end if Missing
        }// end for display cats - Missing
    }// end search_for_adoption()

    public void offer_adoption(ArrayList listOfCats){
        // new Temporary cat object.
        // since this is reporting missing cats,
        // the status "Missing" was added in the initialisation.
        Cat adoptCat =
                new Cat("","",0,"",
                        "",0,"","4Adopt");

        System.out.println("***** Please fill in the Cat information *****");
        System.out.println("\t ***** All fields are required *****");
        System.out.print("\t\t Cat Name: ");
        adoptCat.setCatName(scan.nextLine());
        System.out.print("\t\t Cat color: ");
        adoptCat.setColor(scan.nextLine());
        System.out.print("\t\t Cat age: ");
        adoptCat.setAge(scan.nextInt());
        enterKey = scan.nextLine();
        System.out.print("\t\t Cat Gender: m/f: ");
        adoptCat.setGender(scan.nextLine());
        System.out.print("\t\t Cat breed: ");
        adoptCat.setBreed(scan.nextLine());
        System.out.print("\t\t Cat weight: ");
        adoptCat.setWeight(scan.nextInt());
        enterKey = scan.nextLine();
        System.out.print("\t\t Your Contact #: ");
        adoptCat.setContact(scan.nextLine());

        listOfCats.add(adoptCat);
        System.out.println("***** CAT Info is *****");
        System.out.println(adoptCat.toString());
        System.out.println("***** We will put your offer in the list  *****");
        System.out.println("\t\t\t***** MEOW MEOW  *****");
    }// end offer_adoption()


    public void cat_setting(ArrayList listOfCats){
        int numberOfDays=0;
        String city;
        System.out.println("");
        System.out.println("\tWe offer cat setting service");
        System.out.print("\tPlease Enter number of days:");
        numberOfDays = scan.nextInt();
        enterKey = scan.nextLine();
        System.out.print("\tPlease Enter City for service:");
        city = scan.nextLine();
        System.out.println("\tYou may visit these service locations");
        System.out.println("https://instagram.com/cvvxlu.w?igshid=YmMyMTA2M2Y");
        System.out.println("https://instagram.com/alkhobarcatboarding?igshid=YmMyMTA2M2Y");
        System.out.println("https://instagram.com/7lives_store?igshid=YmMyMTA2M2Y");
    }// end of cat_setting()

    // book for Sterilization appointment
    public void sterilization(){

    }// end of Sterilization

    public void addToBills(ArrayList billsList, String service,int price){
        Bill xBill = new Bill("",0);
        switch(service){
            case "Setting":
                xBill.setService(service);
                xBill.setPrice(price);
                billsList.add(xBill);
                break;
            case "Sterilization":
                xBill.setService(service);
                xBill.setPrice(price);
                billsList.add(xBill);
                break;
            case "Immunization":
                xBill.setService(service);
                xBill.setPrice(price);
                billsList.add(xBill);
                break;
            case "Checkup":
                xBill.setService(service);
                xBill.setPrice(price);
                billsList.add(xBill);
                break;
            case "Shower":
                xBill.setService(service);
                xBill.setPrice(price);
                billsList.add(xBill);
                break;
            case "Haircut":
                xBill.setService(service);
                xBill.setPrice(price);
                billsList.add(xBill);
                break;
            case "Both":
                xBill.setService(service);
                xBill.setPrice(price);
                billsList.add(xBill);
                break;
        }// end of switch
    }// en dof addToBills()

    public void calculate_bill(ArrayList billsList){
        int total = 0;
        System.out.println("\t\tYour Bill is:");
        System.out.println("\t  Service\t\t\t Price");
        System.out.println("\t  -------\t\t\t -----");
        // display and calculate all the services.
        for (int i=0; i< billsList.size(); i++){
            Bill bill = (Bill) billsList.get(i);
            total += bill.getPrice();
            // print formatted
            System.out.printf("\t %s %-15.15s %5d %n",(i+1)+"-",bill.getService(),bill.getPrice());
        } // end of for loop
        System.out.println("\t------------");
        System.out.println("\tTOTAL\t\t-----> "+total);
        System.out.println("\t------------");
        System.out.println("\tMEOW MEOW ");
    }// end of calculate_bBill

}// end of class Customer

